package Pert8;
import java.util.Scanner;

public class IsiArray {
    public static void main(String[] args) {
        Scanner Wilian = new Scanner(System.in);

        System.out.print("Masukkan jumlah elemen Data: ");
        int ukuran = Wilian.nextInt();

        // Deklarasi array
        int[] angka = new int[ukuran];

        // Mengisi array
        for (int i = 0; i < ukuran; i++) {
            System.out.print("Masukkan nilai untuk elemen ke-" + (i + 1) + ": ");
            angka[i] = Wilian.nextInt();
        }

        // Menampilkan isi array (opsional)
        System.out.println("Isi array:");
        for (int i = 0; i < angka.length; i++) {
            System.out.println(angka[i]);
        }
    }
}
