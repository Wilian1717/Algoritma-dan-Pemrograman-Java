// program array dua dimensi
package Pert8;
import java.util.Scanner;

public class ProgramArrayDuaDimensi {
    public static void main(String[] args) {
        Scanner Wilian = new Scanner(System.in);
        String[][] meja = new String[2][3];

        // mengisi setiap meja
        for (int bar = 0; bar < meja.length; bar++) {
            for (int kol = 0; kol < meja[bar].length; kol++) {
                System.out.format("Siapa yang akan duduk di meja [%d,%d]: ", bar, kol);
                meja[bar][kol] = Wilian.nextLine();
            }
        }

        // menampilkan isi Array
        System.out.println("------------------------------------------------------");
        for (int bar = 0; bar < meja.length; bar++) {
            for (int kol = 0; kol < meja[bar].length; kol++) {
                System.out.format("%s \t | \t", meja[bar][kol]);
                // %s untuk mengambil data string yg sdh diinput
                // \t untuk memberikan jarak antar string
                // %d untuk tempat data desimal/angka
            }
            System.out.println("");
        }
        System.out.println("------------------------------------------------------");
    }
}
