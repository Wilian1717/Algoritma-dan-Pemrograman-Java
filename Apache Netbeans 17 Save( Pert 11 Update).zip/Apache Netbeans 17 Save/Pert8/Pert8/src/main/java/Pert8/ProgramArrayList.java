//program array list
package Pert8;
import java.util.ArrayList;

public class ProgramArrayList {
    public static void main(String[] args) {
        ArrayList wilian = new ArrayList(); //membuat objek array list

        //mengisi Kantong Ajaib wilian dengan data
        wilian.add("Senter Pembesar");
        wilian.add(543);
        wilian.add("Tikus");
        wilian.add(135.50);
        wilian.add(true);

        wilian.remove("Tikus"); //menghapus data tikus
        System.out.println(wilian); //menampilkan isi data wilian

        //menampilkan banyak isi wilian
        System.out.println("Kantong Ajaib Wilian Berisi : " + wilian.size() + " Item");
    }
}
