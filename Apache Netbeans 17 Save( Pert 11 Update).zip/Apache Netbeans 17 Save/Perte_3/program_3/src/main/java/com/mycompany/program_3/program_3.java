package com.mycompany.program_3;

import java.util.Scanner;

public class program_3 {
    public static void main(String[] args) {
        double pi, r, luas;
        Scanner input = new Scanner(System.in);

        System.out.print("Masukkan jari-jari lingkaran (r): ");
        r = input.nextDouble();

        pi = 3.14;
        luas = pi * r * r;

        System.out.println("Luas Lingkaran: " + luas + " cm");
    }
}
