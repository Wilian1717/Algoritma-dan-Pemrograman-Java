package program_3;
import java.util.Scanner;

public class program_input_keyboard {
    public static void main(String[] args) {
        String nama, jurusan, email, status;
        int npm, nilai, umur;
        char gender;

        Scanner wilian = new Scanner(System.in);

        System.out.print("Input Nama anda: ");
        nama = wilian.nextLine();

        System.out.print("Input Jurusan anda: ");
        jurusan = wilian.nextLine();

        System.out.print("Input Nilai anda: ");
        nilai = wilian.nextInt();
        wilian.nextLine();

        System.out.print("Input NPM anda: ");
        npm = wilian.nextInt();
        wilian.nextLine();

        System.out.print("Input Gender anda: ");
        gender = wilian.nextLine().charAt(0);

        System.out.print("Input Umur anda: ");
        umur = wilian.nextInt();
        wilian.nextLine();

        System.out.print("Input Email anda: ");
        email = wilian.nextLine();

        System.out.print("Input Status anda: ");
        status = wilian.nextLine();

        System.out.println();
        System.out.println("Nama yang anda input: " + nama);
        System.out.println("Jurusan yang anda input: " + jurusan);
        System.out.println("Nilai yang anda input: " + nilai);
        System.out.println("NPM yang anda input: " + npm);
        System.out.println("Gender yang anda input: " + gender);
        System.out.println("Umur yang anda input: " + umur);
        System.out.println("Email yang anda input: " + email);
        System.out.println("Status yang anda input: " + status);
    }
}
