    package Inheritance;

    import java.util.Scanner;

    public class Main {
        public static void main(String[] args) {
            Scanner Wilian = new Scanner(System.in);

            ClassBangunDatar bd = new ClassBangunDatar();

            System.out.print("Input Nilai Jari-jari: ");
            float jari = Wilian.nextFloat();

            System.out.print("Input Nilai Sisi: ");
            float sisiku = Wilian.nextFloat();

            System.out.print("Input Nilai Alas: ");
            float alasku = Wilian.nextFloat();

            System.out.print("Input Nilai Tinggi: ");
            float tinggiku = Wilian.nextFloat();

            System.out.print("Input Nilai Lebar: ");
            float lebarku = Wilian.nextFloat();

            System.out.print("Input Nilai Panjang: ");
            float panjangku = Wilian.nextFloat();

            // Objek turunan
            ClassPersegi per = new ClassPersegi();
            per.sisi = sisiku;

            ClassSegitiga seg = new ClassSegitiga();
            seg.alas = alasku;
            seg.tinggi = tinggiku;

            ClassPersegiPanjang pp = new ClassPersegiPanjang();
            pp.lebar = lebarku;
            pp.panjang = panjangku;

            ClassLingkaran ling = new ClassLingkaran();
            ling.r = jari;

            // Output
            System.out.println();
            bd.luas();
            bd.keliling();

            System.out.println("==========================");

            ling.luas();
            ling.keliling();

            per.luas();
            per.keliling();

            seg.luas();
            seg.keliling();

            pp.luas();
            pp.keliling();

            Wilian.close();
        }
    }
