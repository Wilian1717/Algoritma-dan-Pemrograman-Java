package Inheritance;

public class ClassSegitiga extends ClassBangunDatar {

    float alas;
    float tinggi;

    @Override
    float luas() {
        float luas = (alas * tinggi) / 2;
        System.out.println("Luas Segitiga: " + luas);
        return luas;
    }

    @Override
    float keliling() {
        // Tidak menampilkan apa-apa, hanya return 0
        return 0;
    }
}
