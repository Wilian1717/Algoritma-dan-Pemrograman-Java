package Inheritance;

public class ClassBangunDatar {

    float luas() {
        System.out.println("Menghitung luas Bangun datar");
        return 0;
    }

    float keliling() {
        System.out.println("Menghitung keliling Bangun datar");
        return 0;
    }
}
