package Inheritance;

public class ClassLingkaran extends ClassBangunDatar {
    float r; // jari-jari

    @Override
    float luas() {
        float luas = (float) (Math.PI * r * r);
        System.out.println("Luas lingkaran: " + luas);
        return luas;
    }

    @Override
    float keliling() {
        float keliling = (float) (2 * Math.PI * r);
        System.out.println("Luas lingkaran: " + keliling);
        return keliling;
    }
}
