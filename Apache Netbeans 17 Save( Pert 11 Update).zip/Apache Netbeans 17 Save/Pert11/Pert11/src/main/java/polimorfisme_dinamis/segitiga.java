package polimorfisme_dinamis;

public class segitiga extends bangun_datar {
    float alas;   // variabel untuk memproses alas
    float tinggi; // variabel untuk memproses tinggi
    float sisi;   // variabel untuk memproses sisi

    // method untuk meminta data dari class main
    public segitiga(int a, int t, int s) {
        alas = a;      // a berfungsi meminta nilai alas dari class main
        tinggi = t;    // t berfungsi meminta nilai tinggi dari class main
        sisi = s;      // s berfungsi meminta nilai sisi dari class main
    }

    @Override
    public float luas() {
        // method untuk memproses luas segitiga
        return (alas * tinggi) / 2;
    }

    @Override
    public float keliling() {
        return this.sisi + this.tinggi + this.sisi;
    }
}
