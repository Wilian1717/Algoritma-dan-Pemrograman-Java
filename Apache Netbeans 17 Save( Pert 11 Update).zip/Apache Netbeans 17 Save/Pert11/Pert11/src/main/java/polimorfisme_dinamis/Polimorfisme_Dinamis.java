package polimorfisme_dinamis;

import java.util.Scanner;

public class Polimorfisme_Dinamis {
    public static void main(String[] args) {
        Scanner Wilian = new Scanner(System.in);

        // Memanggil method luas dan keliling dari superclass
        bangun_datar bd = new bangun_datar();
        bd.luas();
        bd.keliling();

        // ==== Input Persegi ====
        System.out.print("Enter Nilai Sisi Persegi: ");
        int sisiku = Wilian.nextInt();
        persegi per = new persegi(sisiku);

        // ==== Input Lingkaran ====
        System.out.print("Enter Nilai Jari-jari Lingkaran: ");
        int jariku = Wilian.nextInt();
        lingkaran ling = new lingkaran(jariku);

        // ==== Input Segitiga ====
        System.out.print("Enter Nilai Alas Segitiga: ");
        int alasku = Wilian.nextInt();

        System.out.print("Enter Nilai Tinggi Segitiga: ");
        int tinggiku = Wilian.nextInt();

        System.out.print("Enter Nilai Sisi Segitiga: ");
        int sisiseg = Wilian.nextInt();

        segitiga segi = new segitiga(alasku, tinggiku, sisiseg);

        // ==== Output Hasil ====
        System.out.println("\n--- HASIL PERHITUNGAN ---");
        System.out.println("Luas Persegi       : " + per.luas());
        System.out.println("Keliling Persegi   : " + per.keliling());

        System.out.println("Luas Lingkaran     : " + ling.luas());
        System.out.println("Keliling Lingkaran : " + ling.keliling());

        System.out.println("Luas Segitiga      : " + segi.luas());
        System.out.println("Keliling Segitiga  : " + segi.keliling());

        Wilian.close();
    }
}
