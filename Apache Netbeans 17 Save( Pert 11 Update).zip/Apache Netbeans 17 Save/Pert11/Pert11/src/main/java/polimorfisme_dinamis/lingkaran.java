package polimorfisme_dinamis;

public class lingkaran extends bangun_datar {
    int r;

    // Method untuk meminta nilai jari-jari dari main class
    public lingkaran(int jari) {
        this.r = jari;
    }

    @Override
    public float luas() {
        return (float) (Math.PI * r * r);
    }

    @Override
    public float keliling() {
        return (float) (2 * Math.PI * r);
    }
}
