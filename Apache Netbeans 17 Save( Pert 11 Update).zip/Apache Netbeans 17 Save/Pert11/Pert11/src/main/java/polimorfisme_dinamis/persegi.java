package polimorfisme_dinamis;

public class persegi extends bangun_datar {
    int sisi;

    // Method untuk meminta data sisi dari main class
    // Memberikan data si ke variabel sisi
    public persegi(int si) {
        this.sisi = si;  // meminta nilai sisi persegi dari main
    }

    @Override
    public float luas() {
        return this.sisi * this.sisi;
    }

    @Override
    public float keliling() {
        return this.sisi * 4;
    }
}
