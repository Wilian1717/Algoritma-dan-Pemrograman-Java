package polimorfisme_dinamis;

public class bangun_datar {

    float luas() {
        System.out.println("Menghitung Luas Bangun Datar");
        System.out.println("--------------------------------");
        return 0;
    }

    float keliling() {
        System.out.println("Menghitung Keliling Bangun Datar");
        System.out.println("--------------------------------");
        return 0;
    }
}
