package Pert9Mobil; // class biasa

public class Mobil
{
    // class biasa berisi atribut
    String nama_mobil;
    String merk;
    String warna;
    int tahun;
    String jenis_transmisi;
    String tipe_mesin;
    int kapasitas_penumpang;
    double harga;
    String Plat_nomor;
    boolean tersedia;
    String jenis_bahan_bakar;
}