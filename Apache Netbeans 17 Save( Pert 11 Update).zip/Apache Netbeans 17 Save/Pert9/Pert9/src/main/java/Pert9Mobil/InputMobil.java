package Pert9Mobil; // Sesuaikan dengan package class Mobil

import java.util.Scanner;

public class InputMobil // Nama class sesuai file
{
    public static void main(String[] args)
    {
        Scanner wilian = new Scanner(System.in); // Scanner input
        Mobil mobilku = new Mobil(); // Membuat objek Mobil

        System.out.print("Nama Mobil = ");
        mobilku.nama_mobil = wilian.nextLine();

        System.out.print("Merk Mobil = ");
        mobilku.merk = wilian.nextLine();

        System.out.print("Warna Mobil = ");
        mobilku.warna = wilian.nextLine();

        System.out.print("Tahun Mobil = ");
        mobilku.tahun = wilian.nextInt();
        wilian.nextLine(); // Buang enter

        System.out.print("Jenis Transmisi = ");
        mobilku.jenis_transmisi = wilian.nextLine();

        System.out.print("Tipe Mesin = ");
        mobilku.tipe_mesin = wilian.nextLine();

        System.out.print("Kapasitas Penumpang = ");
        mobilku.kapasitas_penumpang = wilian.nextInt();

        System.out.print("Harga Mobil = ");
        mobilku.harga = wilian.nextDouble();
        wilian.nextLine(); // Buang enter

        System.out.print("Plat Nomor = ");
        mobilku.Plat_nomor = wilian.nextLine();

        System.out.print("Tersedia (true/false) = ");
        mobilku.tersedia = wilian.nextBoolean();
        wilian.nextLine(); // Buang enter

        System.out.print("Jenis Bahan Bakar = ");
        mobilku.jenis_bahan_bakar = wilian.nextLine();

        // Output semua atribut
        System.out.println("\n=== Data Mobil Setelah Diinput ===");
        System.out.println("Nama Mobil           = " + mobilku.nama_mobil);
        System.out.println("Merk Mobil           = " + mobilku.merk);
        System.out.println("Warna Mobil          = " + mobilku.warna);
        System.out.println("Tahun Mobil          = " + mobilku.tahun);
        System.out.println("Jenis Transmisi      = " + mobilku.jenis_transmisi);
        System.out.println("Tipe Mesin           = " + mobilku.tipe_mesin);
        System.out.println("Kapasitas Penumpang  = " + mobilku.kapasitas_penumpang);
        System.out.println("Harga Mobil          = " + mobilku.harga);
        System.out.println("Plat Nomor           = " + mobilku.Plat_nomor);
        System.out.println("Tersedia             = " + mobilku.tersedia);
        System.out.println("Jenis Bahan Bakar    = " + mobilku.jenis_bahan_bakar);
    }
}
