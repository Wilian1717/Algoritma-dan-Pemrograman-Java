package Pert9; // class utama
import java.util.Scanner;

public class Game {
    public static void main(String[] args) {
        Scanner upb = new Scanner(System.in);

        // membuat objek player
        Player wilian = new Player();

        // mengisi atribut player
        System.out.print("Input Score Healthpoin = ");
        wilian.healthPoin = upb.nextInt();
        wilian.name = "Elden Ring";
        wilian.speed = 78;

        // menjalankan method
        wilian.run();

        if (wilian.isDead()) {
            System.out.println("Game Over!");
        }
    }
}
