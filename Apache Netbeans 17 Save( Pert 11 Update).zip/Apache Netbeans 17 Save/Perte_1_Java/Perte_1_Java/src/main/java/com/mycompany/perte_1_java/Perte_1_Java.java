package com.mycompany.perte_1_java;

public class Perte_1_Java {
    public static void main(String[] args) {
        String nama = "Budi";
        String Nama = "Mira";
        String NAMA = "Agung";
        char gender = 'L';
        int umur = 30;
        double nilai = 76.9;
        boolean benar = true;
        boolean salah = false;
        
        // Fixed the syntax error
        double hasil = umur + nilai;
        
        System.out.println("Hello World");
        System.out.println("Happy Learning Java Programming");
        System.out.println(nama);
        System.out.println(Nama);
        System.out.println(NAMA);
        System.out.println(benar);
        System.out.println(salah);
        System.out.println("Hasil = " + hasil);
    }
}
