package NilaiMahasiswaUPB;

import java.util.Scanner;

public class NilaiMahasiswaUPB {

    public static void main(String[] args) {
        Scanner Wilian = new Scanner(System.in);
        String nama, nim, jurusan;
        char grade;
        int n_ts, n_uts, n_tm, n_uas, n_absen;
        double n_akhir;

        System.out.println("======= Menghitung Nilai Mahasiswa UPB =======");
        System.out.print("Masukan Nama        : ");
        nama = Wilian.nextLine();
        System.out.print("Masukan NIM         : ");
        nim = Wilian.nextLine();
        System.out.print("Masukan Jurusan     : ");
        jurusan = Wilian.nextLine();
        System.out.print("Nilai Kehadiran     : ");
        n_absen = Wilian.nextInt();
        System.out.print("Nilai Tugas Terstruktur : ");
        n_ts = Wilian.nextInt();
        System.out.print("Nilai Tugas Mandiri : ");
        n_tm = Wilian.nextInt();
        System.out.print("Nilai UTS           : ");
        n_uts = Wilian.nextInt();
        System.out.print("Nilai UAS           : ");
        n_uas = Wilian.nextInt();

        n_akhir = 0.10 * n_absen + 0.15 * n_ts + 0.30 * n_tm + 0.35 * n_uts + 0.10 * n_uas;

        if (n_akhir >= 80 && n_akhir <= 100) {
            grade = 'A';
        } else if (n_akhir >= 70 && n_akhir < 80) {
            grade = 'B';
        } else if (n_akhir >= 60 && n_akhir < 70) {
            grade = 'C';
        } else if (n_akhir >= 50 && n_akhir < 60) {
            grade = 'D';
        } else {
            grade = 'E';
        }

        // Output Akhir
        System.out.println();
        System.out.println("Atas Nama " + nama + " dengan NIM " + nim);
        System.out.println("dari Jurusan " + jurusan);
        System.out.println("memiliki nilai akhir: " + String.format("%.2f", n_akhir) + " dan Grade: " + grade);

        if (grade == 'A' || grade == 'B' || grade == 'C') {
            System.out.println("dan dinyatakan Lulus");
        } else {
            System.out.println("dan dinyatakan Tidak Lulus");
        }
    }
}
