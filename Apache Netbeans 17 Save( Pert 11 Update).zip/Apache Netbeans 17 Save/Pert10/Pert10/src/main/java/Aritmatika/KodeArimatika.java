package Aritmatika;
import java.util.Scanner;
public class KodeArimatika {

    void penjumlahan() {
        Scanner Wilian = new Scanner(System.in);
        int bil1, bil2, hasil;
        System.out.println("Hitung Penjumlahan");
        System.out.print("Input angka-1 = ");
        bil1 = Wilian.nextInt();
        System.out.print("Input angka-2 = ");
        bil2 = Wilian.nextInt();
        hasil = bil1 + bil2;
        System.out.println("Hasil Penjumlahan = " + hasil);
    }

    void pengurangan() {
        Scanner Wilian = new Scanner(System.in);
        int bil1, bil2, hasil;
        System.out.println("Hitung Pengurangan");
        System.out.print("Input angka-1 = ");
        bil1 = Wilian.nextInt();
        System.out.print("Input angka-2 = ");
        bil2 = Wilian.nextInt();
        hasil = bil1 - bil2;
        System.out.println("Hasil Pengurangan = " + hasil);
    }

    void perkalian() {
        Scanner Wilian = new Scanner(System.in);
        int bil1, bil2, hasil;
        System.out.println("Hitung Perkalian");
        System.out.print("Input angka-1 = ");
        bil1 = Wilian.nextInt();
        System.out.print("Input angka-2 = ");
        bil2 = Wilian.nextInt();
        hasil = bil1 * bil2;
        System.out.println("Hasil Perkalian = " + hasil);
    }

    void pembagian() {
        Scanner Wilian = new Scanner(System.in);
        int bil1, bil2;
        double hasil;
        System.out.println("Hitung Pembagian");
        System.out.print("Input angka-1 = ");
        bil1 = Wilian.nextInt();
        System.out.print("Input angka-2 = ");
        bil2 = Wilian.nextInt();

        if (bil2 == 0) {
            System.out.println("Error: Tidak bisa membagi dengan nol.");
        } else {
            hasil = (double) bil1 / bil2;
            System.out.println("Hasil Pembagian = " + hasil);
        }
    }
}
