package Aritmatika;

public class KelasUtama {
    public static void main(String[] args) {
        KodeArimatika operator = new KodeArimatika(); // Gunakan nama kelas yang benar
        operator.penjumlahan();
        operator.perkalian();
        operator.pengurangan();
        operator.pembagian();
    }
}
