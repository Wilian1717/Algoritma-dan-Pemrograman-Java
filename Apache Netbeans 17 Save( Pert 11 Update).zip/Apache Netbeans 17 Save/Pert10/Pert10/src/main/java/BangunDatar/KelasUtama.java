package BangunDatar;

public class KelasUtama {
    public static void main(String[] args) {
        KodeBangunDatar bangun = new KodeBangunDatar();

        // Bangun datar
        bangun.persegi();
        bangun.persegiPanjang();
        bangun.segitiga();
        bangun.lingkaran();
        bangun.trapesium();
    }
}

