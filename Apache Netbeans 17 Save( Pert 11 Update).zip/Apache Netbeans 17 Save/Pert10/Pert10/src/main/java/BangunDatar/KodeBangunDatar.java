package BangunDatar;

import java.util.Scanner;

public class KodeBangunDatar {
    Scanner input = new Scanner(System.in);

    void persegi() {
        System.out.print("Masukkan sisi persegi: ");
        double s = input.nextDouble();
        double luas = s * s;
        double keliling = 4 * s;
        System.out.println("Luas Persegi: " + luas);
        System.out.println("Keliling Persegi: " + keliling + "\n");
    }

    void persegiPanjang() {
        System.out.print("Masukkan panjang persegi panjang: ");
        double p = input.nextDouble();
        System.out.print("Masukkan lebar persegi panjang: ");
        double l = input.nextDouble();
        double luas = p * l;
        double keliling = 2 * (p + l);
        System.out.println("Luas Persegi Panjang: " + luas);
        System.out.println("Keliling Persegi Panjang: " + keliling + "\n");
    }

    void segitiga() {
        System.out.print("Masukkan alas segitiga: ");
        double a = input.nextDouble();
        System.out.print("Masukkan tinggi segitiga: ");
        double t = input.nextDouble();
        System.out.print("Masukkan sisi b segitiga: ");
        double b = input.nextDouble();
        System.out.print("Masukkan sisi c segitiga: ");
        double c = input.nextDouble();
        double luas = 0.5 * a * t;
        double keliling = a + b + c;
        System.out.println("Luas Segitiga: " + luas);
        System.out.println("Keliling Segitiga: " + keliling + "\n");
    }

    void lingkaran() {
        System.out.print("Masukkan jari-jari lingkaran: ");
        double r = input.nextDouble();
        double luas = Math.PI * r * r;
        double keliling = 2 * Math.PI * r;
        System.out.println("Luas Lingkaran: " + luas);
        System.out.println("Keliling Lingkaran: " + keliling + "\n");
    }

    void trapesium() {
        System.out.print("Masukkan sisi a trapesium: ");
        double a = input.nextDouble();
        System.out.print("Masukkan sisi b trapesium: ");
        double b = input.nextDouble();
        System.out.print("Masukkan sisi c trapesium: ");
        double c = input.nextDouble();
        System.out.print("Masukkan sisi d trapesium: ");
        double d = input.nextDouble();
        System.out.print("Masukkan tinggi trapesium: ");
        double t = input.nextDouble();
        double luas = 0.5 * (a + b) * t;
        double keliling = a + b + c + d;
        System.out.println("Luas Trapesium: " + luas);
        System.out.println("Keliling Trapesium: " + keliling + "\n");
    }
}
