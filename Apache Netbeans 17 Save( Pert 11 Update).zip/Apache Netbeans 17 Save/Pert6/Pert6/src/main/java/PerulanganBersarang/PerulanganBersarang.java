package PerulanganBersarang;

import java.util.Scanner;

public class PerulanganBersarang {
    public static void main(String[] args) {

        Scanner Wilian = new Scanner(System.in);

        // input jumlah baris dan kolom
        System.out.print("Masukkan jumlah baris: ");
        int baris = Wilian.nextInt();

        System.out.print("Masukkan jumlah kolom: ");
        int kolom = Wilian.nextInt();

        // melakukan perulangan sebanyak baris dan kolom
        for (int x = 0; x < baris; x++) {
            for (int y = 0; y < kolom; y++) {
                System.out.format("Perulangan [x=%d, y=%d]%n", x, y);
            }
        }
    }
}
