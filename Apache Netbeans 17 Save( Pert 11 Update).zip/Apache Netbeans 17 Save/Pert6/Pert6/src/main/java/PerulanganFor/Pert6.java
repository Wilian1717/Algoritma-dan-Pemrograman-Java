package PerulanganFor;
import java.util.Scanner;

public class Pert6
{
    public static void main(String[] args)
    {
        Scanner Wilian = new Scanner(System.in);
        int n;

        System.out.print("Input Banyak Perulangan = ");
        n = Wilian.nextInt();

        System.out.println("Bilangan Ganjil");
        for (int i = 0; i < n; i++)
        {
            int ganjil = 2 * i + 1;
            System.out.print(ganjil + " ");
        }

        System.out.println();
        System.out.println("Bilangan Genap");
        for (int i = 0; i < n; i++)
        {
            int genap = 2 * (i + 1);
            System.out.print(genap + " ");
        }
    }
}
