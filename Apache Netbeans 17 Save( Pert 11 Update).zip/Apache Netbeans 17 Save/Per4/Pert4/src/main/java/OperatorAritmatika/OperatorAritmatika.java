package OperatorAritmatika;

import java.util.Scanner;

public class OperatorAritmatika {

    public static void main(String[] args) {
        int angka1;
        int angka2;
        int hasil;

        Scanner wilian = new Scanner(System.in);

        // Input angka hanya sekali untuk semua operasi
        System.out.print("Input angka-1: ");
        angka1 = wilian.nextInt();
        System.out.print("Input angka-2: ");
        angka2 = wilian.nextInt();

        // Penjumlahan
        hasil = angka1 + angka2;
        System.out.println("Hasil penjumlahan = " + hasil);

        // Pengurangan
        hasil = angka1 - angka2;
        System.out.println("Hasil pengurangan = " + hasil);

        // Perkalian
        hasil = angka1 * angka2;
        System.out.println("Hasil perkalian = " + hasil);

        // Pembagian
        if (angka2 != 0) {
            hasil = angka1 / angka2;
            System.out.println("Hasil pembagian = " + hasil);
        } else {
            System.out.println("Pembagian dengan nol tidak diperbolehkan.");
        }

        wilian.close();
    }
}
