package OperatorPenugasan;

import java.util.Scanner;

public class OperatorPenugasan {

    public static void main(String[] args) {
        int a;
        int b;

        Scanner wilian = new Scanner(System.in);

        // Input nilai
        System.out.print("Input nilai a: ");
        a = wilian.nextInt();

        System.out.print("Input nilai b: ");
        b = wilian.nextInt();

        // Penambahan
        b += a;
        System.out.println("Penambahan (b += a): " + b);

        // Pengurangan
        b -= a;
        System.out.println("Pengurangan (b -= a): " + b);

        // Perkalian
        b *= a;
        System.out.println("Perkalian (b *= a): " + b);

        // Pembagian
        if (a != 0) {
            b /= a;
            System.out.println("Pembagian (b /= a): " + b);
        } else {
            System.out.println("Pembagian tidak dapat dilakukan karena a = 0.");
        }

        // Sisa bagi
        if (a != 0) {
            b %= a;
            System.out.println("Sisa Bagi (b %= a): " + b);
        } else {
            System.out.println("Sisa bagi tidak dapat dilakukan karena a = 0.");
        }

        wilian.close();
    }
}
