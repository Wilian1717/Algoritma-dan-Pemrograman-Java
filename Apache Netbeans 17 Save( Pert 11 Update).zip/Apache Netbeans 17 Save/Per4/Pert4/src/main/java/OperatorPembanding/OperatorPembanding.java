package OperatorPembanding;

import java.util.Scanner;

public class OperatorPembanding {

    public static void main(String[] args) {
        int nilaiA;
        int nilaiB;
        boolean hasil;

        Scanner wilian = new Scanner(System.in);

        // Input nilai
        System.out.print("Input nilai A: ");
        nilaiA = wilian.nextInt();

        System.out.print("Input nilai B: ");
        nilaiB = wilian.nextInt();

        // apakah A lebih besar dari B?
        hasil = nilaiA > nilaiB;
        System.out.println("Apakah A > B? " + hasil);

        // apakah A lebih kecil dari B?
        hasil = nilaiA < nilaiB;
        System.out.println("Apakah A < B? " + hasil);

        // apakah A lebih besar sama dengan B?
        hasil = nilaiA >= nilaiB;
        System.out.println("Apakah A >= B? " + hasil);

        // apakah A lebih kecil sama dengan B?
        hasil = nilaiA <= nilaiB;
        System.out.println("Apakah A <= B? " + hasil);

        // apakah nilai A sama dengan B?
        hasil = nilaiA == nilaiB;
        System.out.println("Apakah A == B? " + hasil);

        // apakah nilai A tidak sama dengan B?
        hasil = nilaiA != nilaiB;
        System.out.println("Apakah A != B? " + hasil);

        wilian.close();
    }
}
